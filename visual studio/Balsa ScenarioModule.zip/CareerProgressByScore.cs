﻿using System;

using Scenarios.Data;
using Scenarios.Data.UI;

using UI.MMX.Data;

namespace Scenarios.Modules
{
    [ScenarioModule(listName = "", tooltipDescription = "")]
    public class $safeitemname$ : ScenarioModule
	{
		[Serializable]
    public class Data : ScenarioModuleData
    {
        [CfgField]
        public ScnTriggerInput inputTrigger = new ScnTriggerInput();

        protected override void OnGetScenarioEditorData(ContentData content)
        {
            content.AddMany
            (
                new ScnTriggerInputField(inputTrigger, mission, content)
            );

            base.OnGetScenarioEditorData(content);
        }
    }

    private Data data;

    protected internal override void OnScenarioStarting(ScenarioModuleData mData, bool asServer)
    {
        if (mData is Data data)
        {
            this.data = data;
            data.inputTrigger.InitTrigger(mData, OnTrigger);
        }
    }

    private void OnTrigger()
    {
        if (data.enabled)
        {
        }
    }
}
}